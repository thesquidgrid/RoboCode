#!/usr/bin/env pybricks-micropython
#from pybricks.hubs import EV3Brick
#from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
 #                                InfraredSensor, UltrasonicSensor, GyroSensor)
#from pybricks.parameters import Port, Stop, Direction, Button, Color
#from pybricks.tools import wait, StopWatch, DataLog
#from pybricks.robotics import DriveBase
#from pybricks.media.ev3dev import SoundFile, ImageFile

# Modules to Import
#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.media.ev3dev import Image, ImageFile
from pybricks.ev3devices import Motor, ColorSensor
from pybricks.nxtdevices import UltrasonicSensor, TouchSensor, LightSensor
from pybricks.parameters import Port, Color, Stop
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
import time
POSSIBLE_COLORS = [Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.BLACK]

# Objects to 
#light sensor to determine if goal is not guarded
#motors to drive


left = Motor(Port.B)
right = Motor(Port.A)
ultraSonic = UltrasonicSensor(Port.S3)
light = ColorSensor(Port.S2)
puck = Motor(Port.C)
robot_drive = DriveBase(left, right, 55.5, 104)


#loads a silly image
ev3_img = Image("erm3.png")
ev3 = EV3Brick()
ev3.screen.load_image(ev3_img)


"""
robot_drive.straight(550) 
color = light.color

while(color==Color.WHITE):
    robot_drive.straight(20)#small amoubt
    color=light.color

 # get it a little behind the line
robot_drive.turn(-145)

color = light.color
while(color == Color.WHITE):
    robot_drive.turn(20)# turn a little bit to the left to get on track
"""


low = 4
high = 37
midpoint = (high + low) / 2
PROPORTIONAL_GAIN = 1.01


#timer = watch.time()
# Define the target light level and the base speed
target_light_level = 50  # Adjust this value based on your environment
base_speed = 100

# Main control loop
while True:
    # Read the light sensor value
    light_level = light.reflection()

    # Calculate the steering based on the difference between current and target light levels
    steering = (light_level - target_light_level) * 0.5

    # Calculate the speed of each motor
    left_speed = base_speed - steering
    right_speed = base_speed + steering

    # Limit the speeds to stay within the range [-100, 100]
    left_speed = max(min(left_speed, 100), -100)
    right_speed = max(min(right_speed, 100), -100)

    # Set the motor speeds using the drivebase
    robot_drive.drive(left_speed, right_speed)

    # Wait for a short time to avoid tight loops
    wait(10)





# Actions
"""
color = light.color
print(color)
for cycle in range(100000):
    
    light_level = light.reflection()
    #timer = watch.time()
    #data.log(timer, light_level, midpoint)
    # If the reflected light is too high turn left
    while light_level > midpoint:
        robot_drive.drive(50, 10)
        light_level = light.reflection()
        print(light_level)
        time.sleep(1)
        
    # If the reflected light is too low turn right
    while light_level < midpoint:
        robot_drive.drive(50, -10)
        light_level = light.reflection() 
        print(light_level)
        time.sleep(1)

    

left.stop()
right.stop()



#line following
"""
"""
for x in range(10000):
    deviation = light.reflection()-midpoint
    turn_rate = deviation * PROPORTIONAL_GAIN 
    robot_drive.drive(100,turn_rate)
    print(light.reflection())
    print(light.color)
    time.sleep(1)


robot_drive.turn(-200)
"""
"""
puckgone1 = False
while(puckgone1==False):
    if(ultraSonic.distance() == 200):
        puckgone1 = True
        puck.run_angle(10000,110,then=Stop.HOLD, wait=True)
        puck.run_angle(10000,-110,then=Stop.HOLD, wait=True)
       """
